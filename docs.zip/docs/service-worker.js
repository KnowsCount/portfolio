/**
 * Welcome to your Workbox-powered service worker!
 *
 * You'll need to register this file in your web app and you should
 * disable HTTP caching for this file too.
 * See https://goo.gl/nhQhGp
 *
 * The rest of the code is auto-generated. Please don't update this file
 * directly; instead, make changes to your Workbox build configuration
 * and re-run your build process.
 * See https://goo.gl/2aRDsh
 */

importScripts("https://storage.googleapis.com/workbox-cdn/releases/3.6.3/workbox-sw.js");

/**
 * The workboxSW.precacheAndRoute() method efficiently caches and responds to
 * requests for URLs in the manifest.
 * See https://goo.gl/S9QRab
 */
self.__precacheManifest = [
  {
    "url": "404.html",
    "revision": "a84842e191e38e898b403de8e036ce3d"
  },
  {
    "url": "assets/css/0.styles.bae36bfb.css",
    "revision": "7322c4a7db1e615f128ae06c4720fa98"
  },
  {
    "url": "assets/js/2.0a8f19ca.js",
    "revision": "d0db20be46e0f6833a7467d3bca33cb8"
  },
  {
    "url": "assets/js/3.0405d7dd.js",
    "revision": "ac38f9536976949dc6d40fe214c88d31"
  },
  {
    "url": "assets/js/4.04fa854f.js",
    "revision": "5ed666958f39d86fd59c7285b014418b"
  },
  {
    "url": "assets/js/5.e15b3887.js",
    "revision": "e9a072c85a8b577e636fded8e4fb48db"
  },
  {
    "url": "assets/js/app.8102d0c6.js",
    "revision": "5b6b7e165a68cdee243f5a1b0cef5aa0"
  },
  {
    "url": "index.html",
    "revision": "1a7dba5b3e5e5a4ae050913ca5744293"
  }
].concat(self.__precacheManifest || []);
workbox.precaching.suppressWarnings();
workbox.precaching.precacheAndRoute(self.__precacheManifest, {});
addEventListener('message', event => {
  const replyPort = event.ports[0]
  const message = event.data
  if (replyPort && message && message.type === 'skip-waiting') {
    event.waitUntil(
      self.skipWaiting().then(
        () => replyPort.postMessage({ error: null }),
        error => replyPort.postMessage({ error })
      )
    )
  }
})
